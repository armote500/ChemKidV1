Blockly.Msg.CHEMKID_GET_LUX_TITLE = "เคมคิด";
Blockly.Msg.CHEMKID_GET_LUX_TOOLTIP = "เคมคิด อ่านค่าสี หรืีอความเข้มข้นของสารละลาย";
Blockly.Msg.CHEMKID_GET_LUX_HELPURL = "";
